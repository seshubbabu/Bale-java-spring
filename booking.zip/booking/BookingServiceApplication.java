package com.marlabs.booking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.FilterType;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * @author Sivasankar.Thalavai
 *
 *         Mar 7, 2023
 *
 */

@SpringBootApplication
@ComponentScan(basePackages = "com.marlabs.booking.*", excludeFilters = {
		@ComponentScan.Filter(type = FilterType.REGEX, pattern = {}) })
@EnableJpaAuditing
@EnableScheduling
public class BookingServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookingServiceApplication.class, args);
	}

}