package com.marlabs.booking.workspace.service;

import org.springframework.stereotype.Service;

import com.marlabs.booking.workspace.common.dto.BlockRequestDTO;
import com.marlabs.booking.workspace.common.dto.CommonResponseDTO;

/**
 * @author Sivasankar.Thalavai
 *
 *         Mar 7, 2023
 *
 */

@Service
public interface BookingService {

	CommonResponseDTO<?> blockSeat(BlockRequestDTO blockRequestDTO);

}
