package com.marlabs.booking.workspace.service;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Service;

import com.marlabs.booking.workspace.common.dto.CommonResponseDTO;
import com.marlabs.booking.workspace.dto.AdminDashboardDetailsRequestDTO;
import com.marlabs.booking.workspace.dto.AdminDashboardDetailsResponseDTO;
import com.marlabs.booking.workspace.dto.AdminDashboardStatsRequestDTO;
import com.marlabs.booking.workspace.dto.AdminDashboardStatsResponseDTO;
import com.marlabs.booking.workspace.dto.BookingCancellationRequestDTO;
import com.marlabs.booking.workspace.dto.BookingCancellationResponseDTO;
import com.marlabs.booking.workspace.dto.BookingDetailResponseDTO;
import com.marlabs.booking.workspace.dto.BookingDetailsRequestDTO;
import com.marlabs.booking.workspace.dto.BookingRequestDTO;
import com.marlabs.booking.workspace.dto.BookingSearchDetailsRequestDTO;
import com.marlabs.booking.workspace.dto.DefaultPreferencesRequestDTO;
import com.marlabs.booking.workspace.dto.OfficeWorkspaceResponseDTO;
import com.marlabs.booking.workspace.dto.WorkspaceLayoutRequestDTO;
import com.marlabs.booking.workspace.dto.WorkspaceLayoutResponseDTO;
import com.marlabs.booking.workspace.dto.WorkspaceLocationResponseDTO;

/**
 * @author Sivasankar.Thalavai
 *
 *         Mar 7, 2023
 *
 */

@Service
public interface WorkspaceBookingService {

	CommonResponseDTO<?> createBooking(BookingRequestDTO workspaceBookingRequest) throws ParseException;

	CommonResponseDTO<List<OfficeWorkspaceResponseDTO>> fetchWorkspaceDetailsByLocation(String locationCode);

	CommonResponseDTO<WorkspaceLayoutResponseDTO> fetchWorkspaceLayoutDetails(
			WorkspaceLayoutRequestDTO workspaceLayoutRequest);

	CommonResponseDTO<List<WorkspaceLocationResponseDTO>> fetchWorkspaceLocationsDetails();

	CommonResponseDTO<List<BookingCancellationResponseDTO>> cancelBooking(
			List<BookingCancellationRequestDTO> bookingCancellationRequest);

	CommonResponseDTO<List<BookingDetailResponseDTO>> fetchBookingDetails(BookingDetailsRequestDTO bookingDetailsReq);

	CommonResponseDTO<AdminDashboardDetailsResponseDTO> fetchAdminDashboardDetails(
			AdminDashboardDetailsRequestDTO adminDashboardDetailsReq);

	CommonResponseDTO<AdminDashboardStatsResponseDTO> fetchAdminDashboardStats(
			AdminDashboardStatsRequestDTO adminDashboardStatsReq);

	byte[] downloadAdminDashboardDetails(AdminDashboardDetailsRequestDTO adminDashboardDetailsReq,
			HttpServletResponse response) throws IOException;

	CommonResponseDTO<List<Object>> fetchBookingSearchDetails(

			BookingSearchDetailsRequestDTO bookingSearchDetailsRequestDTO);

	CommonResponseDTO<String> makeAsDefaultPrefrence(DefaultPreferencesRequestDTO defaultPreferencesReq);
}
