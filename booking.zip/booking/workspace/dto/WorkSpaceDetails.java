package com.marlabs.booking.workspace.dto;

import lombok.Data;

@Data
public class WorkSpaceDetails {

	private String userId;

	private String userName;

	private String userType;

}
