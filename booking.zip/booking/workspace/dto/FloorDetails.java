package com.marlabs.booking.workspace.dto;

import java.util.List;

import lombok.Data;

@Data
public class FloorDetails {

	private List<String> floorNos;

}
