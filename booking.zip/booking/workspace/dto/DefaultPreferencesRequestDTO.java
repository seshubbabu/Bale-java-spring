package com.marlabs.booking.workspace.dto;

import java.math.BigInteger;

import javax.persistence.Column;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.marlabs.booking.workspace.enums.BookingType;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.ToString;

/**
 * @author Sivasankar.Thalavai
 *
 *         May 26, 2023
 */
@Data
@ToString(includeFieldNames = true)
@AllArgsConstructor
@RequiredArgsConstructor
public class DefaultPreferencesRequestDTO {

	@JsonProperty("bookingId")
	private BigInteger bookingId;

	@JsonProperty("bookingDate")
	@NotBlank(message = "From Date cannot not be Blank")
	@Pattern(regexp = "^([0-2][0-9]||3[0-1])-(0[0-9]||1[0-2])-([0-9][0-9])?[0-9][0-9]$")
	@JsonFormat(pattern = "dd-MM-yyyy")
	private String bookingDate;

	@JsonProperty("status")
	private boolean status;

	@Column(name = "booking_type", nullable = false)
	private BookingType bookingType;
}
