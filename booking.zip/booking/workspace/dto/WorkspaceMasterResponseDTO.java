package com.marlabs.booking.workspace.dto;

public class WorkspaceMasterResponseDTO {

}
