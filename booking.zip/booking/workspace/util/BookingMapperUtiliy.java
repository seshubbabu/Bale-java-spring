package com.marlabs.booking.workspace.util;

import org.springframework.stereotype.Component;

/**
 * @author Sivasankar.Thalavai
 *
 *         Mar 11, 2023
 */
@Component
public class BookingMapperUtiliy {

}
