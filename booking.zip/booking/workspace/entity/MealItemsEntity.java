package com.marlabs.booking.workspace.entity;

import java.math.BigInteger;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.marlabs.booking.workspace.enums.BookingStatusType;
import com.marlabs.booking.workspace.enums.BookingType;
import com.marlabs.booking.workspace.enums.UserType;

import lombok.Data;
import lombok.ToString;

/**
 * @author Sivasankar.Thalavai
 *
 *         Mar 13, 2023
 */
@Entity
@Table(name = "meal_items", schema = "workspace")
@Data
@ToString(includeFieldNames = true)
public class MealItemsEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "meal_item_id", columnDefinition = "bigint", nullable = false)
	private BigInteger mealItemId;

	@Column(name = "booking_id", columnDefinition = "bigint", nullable = false)
	private BigInteger bookingId;

	@Column(name = "booking_type", nullable = false)
	@Enumerated(EnumType.STRING)
	private BookingType bookingType;

	@Column(name = "booking_date")
	private Date bookingDate;

	@Column(name = "employee_id")
	private String employeeId;

	@Column(name = "employee_name")
	private String employeeName;

	@Column(name = "requested_for", nullable = false)
	@Enumerated(EnumType.STRING)
	private UserType userType;

	@Column(name = "no_of_lunch")
	private int noOfLunch;

	@Column(name = "no_of_dinner")
	private int noOfDinner;

	@Column(name = "location_code", nullable = false)
	private String locationCode;

	@Column(name = "city", nullable = false)
	private String city;

	@Column(name = "country", nullable = false)
	private String country;

	@Column(name = "status", nullable = false)
	@Enumerated(EnumType.STRING)
	private BookingStatusType status;

}