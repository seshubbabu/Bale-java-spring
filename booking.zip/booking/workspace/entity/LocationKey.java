package com.marlabs.booking.workspace.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.Size;

/**
 * @author Sivasankar.Thalavai
 *
 *         Mar 20, 2023
 */
@Embeddable
public class LocationKey implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2581110957868057258L;

	@Column(name = "location_code", length = 10, nullable = false)
	@Size(min = 3, max = 10)
	private String locationCode;

	@Column(name = "floor_no", length = 3, nullable = false)
	@Size(min = 1, max = 3)
	private int floorNo;
}
