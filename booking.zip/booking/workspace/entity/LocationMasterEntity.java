package com.marlabs.booking.workspace.entity;

import java.io.Serializable;
import java.math.BigInteger;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * @author Sivasankar.Thalavai
 *
 *         Mar 20, 2023
 */
@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "location_master", schema = "workspace", uniqueConstraints = {
		@UniqueConstraint(columnNames = { "location_code", "location_name", "floor_no" }) })
@ToString(includeFieldNames = true)
public class LocationMasterEntity extends BaseEntity<String> implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2013683770677665694L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "location_master_id", columnDefinition = "bigint", nullable = false)
	private BigInteger locationMasterId;

	@Column(name = "location_code", length = 20, nullable = false)
	@Size(min = 3, max = 20)
	private String locationCode;

	@Column(name = "location_name", length = 50, nullable = false)
	@Size(min = 1, max = 50)
	private String locationName;

	@Column(name = "location_desc", length = 100)
	private String locationDesc;

	@Column(name = "floor_no", length = 20, nullable = false)
	private String floorNo;

	@Column(name = "city", length = 50, nullable = false)
	private String city;

	@Column(name = "state", length = 50, nullable = false)
	private String state;

	@Column(name = "country", length = 50, nullable = false)
	private String country;

	@Column(name = "status", columnDefinition = "BIT default 1", nullable = false)
	private boolean status;

}