package com.marlabs.booking.workspace.entity;

import java.io.Serializable;
import java.math.BigInteger;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.hibernate.annotations.Type;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * @author Sivasankar.Thalavai
 *
 *         Mar 20, 2023
 */
@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "workspace_type_master", schema = "workspace")
@ToString(includeFieldNames = true)
public class WorkspaceTypeMasterEntity extends BaseEntity<String> implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2013683770677665694L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "workspace_type_master_id", columnDefinition = "bigint", nullable = false)
	private BigInteger workspaceTypeMasterId;

	@Column(name = "workspace_type", length = 20, nullable = false)
	@Size(min = 3, max = 10)
	private String workspaceType;

	@Column(name = "workspace_type_code", length = 50, nullable = false)
	@Size(min = 1, max = 50)
	private String workspaceTypeCode;

	@Column(name = "workspace_name", length = 100)
	private String workspaceName;

	@Column(name = "location_master_id", columnDefinition = "bigint", nullable = false)
	private BigInteger locationMasterId;

	@Column(name = "capacity", length = 50, nullable = false)
	private Integer capacity;

	@Type(type = "numeric_boolean")
	@Column(name = "status", columnDefinition = "BIT default 1", nullable = false)
	private boolean status;

}