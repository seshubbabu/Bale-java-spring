package com.marlabs.booking.workspace.entity;

import java.io.Serializable;
import java.math.BigInteger;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.marlabs.booking.workspace.enums.BookingStatusType;
import com.marlabs.booking.workspace.enums.BookingType;
import com.marlabs.booking.workspace.enums.UserType;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * @author Sivasankar.Thalavai
 *
 *         Mar 10, 2023
 */
@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "booking_details", schema = "workspace")
@ToString(includeFieldNames = true)
public class BookingDetailsEntity extends BaseEntity<String> implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -354966634645990742L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "booking_id", columnDefinition = "bigint")
	private BigInteger bookingId;

	@Column(name = "booking_type", nullable = false)
	@Enumerated(EnumType.STRING)
	private BookingType bookingType;

	@Column(name = "requested_date", nullable = false)
	private Date requestedDate;

	@Column(name = "requester_id", nullable = false)
	private String requesterId;

	@Column(name = "requester_name", nullable = false)
	private String requesterName;

	@Column(name = "requested_for", nullable = false)
	@Enumerated(EnumType.STRING)
	private UserType userType;

	@Column(name = "booking_start_date", nullable = false)
	private Date bookingStartDate;

	@Column(name = "booking_end_date", nullable = false)
	private Date bookingEndDate;

	@Column(name = "status", nullable = false)
	@Enumerated(EnumType.STRING)
	private BookingStatusType status;

	@Column(name = "is_default_booking_preference")
	private boolean isDefaultBookingPreference = false;
}
