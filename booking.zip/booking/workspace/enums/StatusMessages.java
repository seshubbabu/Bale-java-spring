package com.marlabs.booking.workspace.enums;

/**
 * @author Sivasankar.Thalavai
 *
 *         Mar 10, 2023
 */
public class StatusMessages {

}
