package com.marlabs.booking.workspace;

/**
 * @author Sivasankar.Thalavai
 *
 *         May 18, 2023
 */
public class BookingConstants {

	public static final String MARTIAN = "MARTIAN";

}
