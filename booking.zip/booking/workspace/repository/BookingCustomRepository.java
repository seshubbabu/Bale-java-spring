package com.marlabs.booking.workspace.repository;

import java.math.BigInteger;
/**
 * 
 * @author Parandhamaiah.Naidu
 *
 */
import java.sql.Date;
import java.util.List;

import com.marlabs.booking.workspace.dto.AdminDashboardDetailsRequestDTO;
import com.marlabs.booking.workspace.dto.AdminDashboardDetailsResponseDTO;
import com.marlabs.booking.workspace.dto.AdminDashboardStatsRequestDTO;
import com.marlabs.booking.workspace.dto.AdminDashboardStatsResponseDTO;
import com.marlabs.booking.workspace.dto.BookingCancellationRequestDTO;
import com.marlabs.booking.workspace.dto.BookingDetailsRequestDTO;
import com.marlabs.booking.workspace.dto.BookingDetailsResponseDTO;
import com.marlabs.booking.workspace.dto.BookingSearchDetailsRequestDTO;
import com.marlabs.booking.workspace.dto.WorkspaceLayoutDTO;

/**
 * @author Sivasankar.Thalavai
 *
 *         May 16, 2023
 */
public interface BookingCustomRepository {

	List<WorkspaceLocationFlatResponseDTO> getlocationDetails();

	List<BookingDetailsResponseDTO> getBookingDetails(BigInteger bookingId);

	List<WorkspaceLayoutDTO> getWorkspaceLayoutDetails(Date date, String workspaceType, String locationCode,
			String floorNo, BigInteger locationMasterId);

	void cancelBooking(BookingCancellationRequestDTO bookingCancellationRequest);

	List<BookingDetailsResponseDTO> getPreviousAndFutureBookingDetails(BookingDetailsRequestDTO bookingDetailsReq);

	AdminDashboardDetailsResponseDTO getAdminDashboardDetails(AdminDashboardDetailsRequestDTO adminDashboardDetailsReq);

	AdminDashboardStatsResponseDTO getAdminDashboardStatsDetails(
			AdminDashboardStatsRequestDTO adminDashboardDetailsReq);

	List<Object> getBookingSearchDetails(BookingSearchDetailsRequestDTO bookingSearchDetailsRequestDTO);

	List<Object> getBookingSeatDetails(BookingSearchDetailsRequestDTO bookingSearchDetailsRequestDTO);

	int getTotalSeatCount(BookingDetailsRequestDTO bookingDetailsReq);
}