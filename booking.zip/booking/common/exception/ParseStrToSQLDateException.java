package com.marlabs.booking.common.exception;

import lombok.Getter;

/**
 * @author Sivasankar.Thalavai
 *
 *         Mar 14, 2023
 */
@Getter
public class ParseStrToSQLDateException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4624208089410375288L;

	public ParseStrToSQLDateException(String string, String string2, Throwable cause) {

	}

}
