package com.marlabs.booking.common.util;

public class CommonUtil {

}
